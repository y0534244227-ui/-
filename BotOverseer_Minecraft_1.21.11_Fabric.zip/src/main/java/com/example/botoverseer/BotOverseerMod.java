package com.example.botoverseer;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;

import java.util.Arrays;
import java.util.List;

public class BotOverseerMod implements ModInitializer {
    public static final String MOD_ID = "botoverseer";

    private static final List<String> CATEGORIES = Arrays.asList(
        "potion_brewer", 
        "diamond_multiplier", 
        "miner", 
        "builder", 
        "crop_harvester", 
        "fighter", 
        "our_builder"
    );

    @Override
    public void onInitialize() {
        System.out.println("Initializing Bot Overseer Mod specifically compiled for Minecraft 1.21.11 (Java Edition)...");

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                CommandManager.literal("deploybots")
                    .then(CommandManager.argument("role", StringArgumentType.word())
                        .suggests((context, builder) -> CommandSource.suggestMatching(CATEGORIES, builder))
                        .executes(context -> {
                            ServerCommandSource source = context.getSource();
                            ServerPlayerEntity player = source.getPlayerOrThrow();
                            String role = StringArgumentType.getString(context, "role").toLowerCase();

                            if (!CATEGORIES.contains(role)) {
                                source.sendError(Text.literal("תפקיד לא תקין! בחר: potion_brewer, diamond_multiplier, miner, builder, crop_harvester, fighter, our_builder"));
                                return 0;
                            }

                            return deployBots(player, role);
                        })
                    )
            );

            dispatcher.register(
                CommandManager.literal("buildanything")
                    .then(CommandManager.argument("what_to_build", StringArgumentType.greedyString())
                        .executes(context -> {
                            ServerCommandSource source = context.getSource();
                            ServerPlayerEntity player = source.getPlayerOrThrow();
                            String whatToBuild = StringArgumentType.getString(context, "what_to_build");

                            return buildCustomStructure(player, whatToBuild);
                        })
                    )
            );

            dispatcher.register(
                CommandManager.literal("summonwithonediamond")
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();
                        ServerPlayerEntity player = source.getPlayerOrThrow();
                        return summonWithOneDiamond(player);
                    })
            );

            dispatcher.register(
                CommandManager.literal("spawnabandonedarmy")
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();
                        ServerPlayerEntity player = source.getPlayerOrThrow();
                        return spawnAbandonedArmy(player);
                    })
            );

            dispatcher.register(
                CommandManager.literal("tributeloot")
                    .executes(context -> {
                        ServerCommandSource source = context.getSource();
                        ServerPlayerEntity player = source.getPlayerOrThrow();
                        return giveTribute(player);
                    })
            );
        });
    }

    private int buildCustomStructure(ServerPlayerEntity player, String structureName) {
        BlockPos origin = player.getBlockPos().offset(player.getHorizontalFacing(), 4);
        String nameLower = structureName.toLowerCase();

        player.sendMessage(
            Text.literal(" 10 הבוטים הבונים קיבלו את הסכמטיקה! מתחילים לבנות: " + structureName)
                .formatted(Formatting.YELLOW, Formatting.BOLD),
            false
        );

        if (nameLower.contains("synagogue") || nameLower.contains("בית כנסת")) {
            for (int x = -4; x <= 4; x++) {
                for (int z = -4; z <= 4; z++) {
                    for (int y = 0; y <= 5; y++) {
                        if (x == -4 || x == 4 || z == -4 || z == 4 || y == 0 || y == 5) {
                            player.getWorld().setBlockState(origin.add(x, y, z), Blocks.QUARTZ_BLOCK.getDefaultState());
                        } else {
                            player.getWorld().setBlockState(origin.add(x, y, z), Blocks.AIR.getDefaultState());
                        }
                    }
                }
            }
            player.getWorld().setBlockState(origin.add(0, 1, 0), Blocks.GOLD_BLOCK.getDefaultState());
        } else if (nameLower.contains("orbital") || nameLower.contains("strike") || nameLower.contains("cannon")) {
            for (int x = -2; x <= 2; x++) {
                for (int z = -2; z <= 2; z++) {
                    player.getWorld().setBlockState(origin.add(x, 0, z), Blocks.NETHERITE_BLOCK.getDefaultState());
                }
            }
            player.getWorld().setBlockState(origin.add(0, 1, 0), Blocks.BEACON.getDefaultState());
            for (int y = 2; y <= 15; y++) {
                player.getWorld().setBlockState(origin.add(0, y, 0), Blocks.OBSIDIAN.getDefaultState());
                player.getWorld().setBlockState(origin.add(1, y, 0), Blocks.COPPER_BULB.getDefaultState());
                player.getWorld().setBlockState(origin.add(-1, y, 0), Blocks.COPPER_BULB.getDefaultState());
            }
        } else if (nameLower.contains("castle") || nameLower.contains("טירה") || nameLower.contains("fort")) {
            for (int x = -5; x <= 5; x++) {
                for (int z = -5; z <= 5; z++) {
                    for (int y = 0; y <= 4; y++) {
                        if (x == -5 || x == 5 || z == -5 || z == 5 || y == 0) {
                            player.getWorld().setBlockState(origin.add(x, y, z), Blocks.TUFF_BRICKS.getDefaultState());
                        }
                    }
                }
            }
        } else {
            for (int x = -3; x <= 3; x++) {
                for (int z = -3; z <= 3; z++) {
                    for (int y = 0; y <= 4; y++) {
                        if (x == -3 || x == 3 || z == -3 || z == 3 || y == 4 || y == 0) {
                            player.getWorld().setBlockState(origin.add(x, y, z), Blocks.POLISHED_TUFF.getDefaultState());
                        } else {
                            player.getWorld().setBlockState(origin.add(x, y, z), Blocks.AIR.getDefaultState());
                        }
                    }
                }
            }
            player.getWorld().setBlockState(origin.add(0, 1, 0), Blocks.DIAMOND_BLOCK.getDefaultState());
        }

        player.sendMessage(
            Text.literal(" הבוטים סיימו לבנות את הסכמטיקה של: " + structureName + "!").formatted(Formatting.GREEN, Formatting.BOLD),
            false
        );

        return 1;
    }

    private int summonWithOneDiamond(ServerPlayerEntity player) {
        boolean hasDiamond = false;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isOf(Items.DIAMOND)) {
                stack.decrement(1);
                hasDiamond = true;
                break;
            }
        }

        if (!hasDiamond) {
            player.sendMessage(Text.literal("אתה צריך יהלום 1 בתיק כדי להזמין בוט!").formatted(Formatting.RED), false);
            return 0;
        }

        int botCount = (Math.random() < 0.5) ? 1 : 2;
        for (int i = 0; i < botCount; i++) {
            IronGolemEntity bot = EntityType.IRON_GOLEM.create(player.getWorld());
            if (bot != null) {
                double offsetX = (Math.random() - 0.5) * 3.0;
                double offsetZ = (Math.random() - 0.5) * 3.0;
                bot.refreshPositionAndAngles(
                    player.getX() + offsetX, player.getY(), player.getZ() + offsetZ,
                    player.getYaw(), player.getPitch()
                );

                bot.setCustomName(Text.literal("Diamond Multiplier Bot #" + (i + 1)).formatted(Formatting.AQUA));
                bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND));
                bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.DIAMOND_BLOCK));
                bot.setCustomNameVisible(true);
                player.getWorld().spawnEntity(bot);
            }
        }

        player.sendMessage(
            Text.literal(" הקרבת יהלום 1! נוצרו " + botCount + " בוטים של Diamond Multiplier!").formatted(Formatting.AQUA, Formatting.BOLD),
            false
        );

        return 1;
    }

    private int deployBots(ServerPlayerEntity player, String role) {
        if (role.equals("diamond_multiplier")) {
            return summonWithOneDiamond(player);
        }

        int requiredDiamonds = 10;
        int currentDiamonds = 0;

        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isOf(Items.DIAMOND)) {
                currentDiamonds += stack.getCount();
            }
        }

        if (currentDiamonds < requiredDiamonds) {
            player.sendMessage(
                Text.literal("אתה צריך 10 יהלומים! כרגע יש לך " + currentDiamonds + " יהלומים.")
                    .formatted(Formatting.RED),
                false
            );
            return 0;
        }

        int toRemove = requiredDiamonds;
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isOf(Items.DIAMOND)) {
                if (stack.getCount() <= toRemove) {
                    toRemove -= stack.getCount();
                    player.getInventory().setStack(i, ItemStack.EMPTY);
                } else {
                    stack.decrement(toRemove);
                    toRemove = 0;
                }
            }
            if (toRemove == 0) break;
        }

        for (int i = 0; i < 10; i++) {
            IronGolemEntity bot = EntityType.IRON_GOLEM.create(player.getWorld());
            if (bot != null) {
                double offsetX = (Math.random() - 0.5) * 4.0;
                double offsetZ = (Math.random() - 0.5) * 4.0;
                bot.refreshPositionAndAngles(
                    player.getX() + offsetX, player.getY(), player.getZ() + offsetZ,
                    player.getYaw(), player.getPitch()
                );

                switch (role) {
                    case "potion_brewer":
                        bot.setCustomName(Text.literal("Potion Brewer Bot #" + (i + 1)).formatted(Formatting.LIGHT_PURPLE));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BREWING_STAND));
                        bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.POTION));
                        break;
                    case "miner":
                        bot.setCustomName(Text.literal("Miner Bot #" + (i + 1)).formatted(Formatting.BLUE));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_PICKAXE));
                        bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.TORCH, 64));
                        break;
                    case "builder":
                        bot.setCustomName(Text.literal("Builder Bot #" + (i + 1)).formatted(Formatting.YELLOW));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.WOODEN_PICKAXE));
                        bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.BRICKS, 64));
                        break;
                    case "crop_harvester":
                        bot.setCustomName(Text.literal("Crop Harvester Bot #" + (i + 1)).formatted(Formatting.GREEN));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_HOE));
                        bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.WHEAT_SEEDS, 64));
                        break;
                    case "fighter":
                        bot.setCustomName(Text.literal("Fighter Bot #" + (i + 1)).formatted(Formatting.RED));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
                        bot.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
                        break;
                    case "our_builder":
                        bot.setCustomName(Text.literal("Our Builder Bot #" + (i + 1)).formatted(Formatting.GOLD));
                        bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_AXE));
                        bot.equipStack(EquipmentSlot.OFFHAND, new ItemStack(Items.OAK_PLANKS, 64));
                        break;
                }

                bot.setCustomNameVisible(true);
                player.getWorld().spawnEntity(bot);
            }
        }

        player.sendMessage(
            Text.literal(" הקרבת 10 יהלומים! נפרסו 10 בוטים מסוג " + role.toUpperCase().replace('_', ' ') + "!").formatted(Formatting.GREEN, Formatting.BOLD),
            false
        );

        return 1;
    }

    private int spawnAbandonedArmy(ServerPlayerEntity player) {
        BlockPos pos = player.getBlockPos();
        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                for (int y = 0; y <= 2; y++) {
                    if (x == -1 || x == 1 || z == -1 || z == 1 || y == 2) {
                        player.getWorld().setBlockState(pos.add(x, y, z), Blocks.OAK_FENCE.getDefaultState());
                    }
                }
            }
        }

        for (int i = 0; i < 8; i++) {
            PillagerEntity raider = EntityType.PILLAGER.create(player.getWorld());
            if (raider != null) {
                double offsetX = (Math.random() - 0.5) * 8.0;
                double offsetZ = (Math.random() - 0.5) * 8.0;
                raider.refreshPositionAndAngles(
                    player.getX() + offsetX, player.getY(), player.getZ() + offsetZ,
                    player.getYaw(), player.getPitch()
                );
                raider.setCustomName(Text.literal("Abandoned Raider #" + (i + 1)).formatted(Formatting.DARK_RED));
                raider.setCustomNameVisible(true);
                player.getWorld().spawnEntity(raider);
            }
        }

        player.sendMessage(
            Text.literal(" אזהרה! צבא נטוש כלא אותך בכלוב גדרות עץ! תן ציוד/שלל בעזרת /tributeloot או שיוכרז מלחמה!").formatted(Formatting.DARK_RED, Formatting.BOLD),
            false
        );

        return 1;
    }

    private int giveTribute(ServerPlayerEntity player) {
        ItemStack mainHand = player.getMainHandStack();
        if (mainHand.isEmpty()) {
            player.sendMessage(Text.literal("החזק שלל (יהלומים/זהב/ברזל) ביד לביצוע מחווה/בניית אמון!").formatted(Formatting.YELLOW), false);
            return 0;
        }

        String item = mainHand.getItem().getName().getString();
        int count = mainHand.getCount();
        player.setStackInHand(net.minecraft.util.Hand.MAIN_HAND, ItemStack.EMPTY);

        player.sendMessage(
            Text.literal(" מסרת " + count + "x " + item + " לצבא הנטוש! נבנה אמון והמלחמה נמנעה.").formatted(Formatting.GOLD, Formatting.BOLD),
            false
        );

        return 1;
    }
}